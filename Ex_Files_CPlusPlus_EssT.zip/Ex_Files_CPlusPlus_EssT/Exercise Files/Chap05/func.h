// func.h by Bill Weinman <http://bw.org/>

#ifndef FUNC_H_
#define FUNC_H_

void func();

#endif // FUNC_H_
