// hello.cpp by Bill Weinman <http://bw.org/>
#include <cstdio>
using namespace std;

int main()
{
    puts("Hello, World!");
    return 0;
}
